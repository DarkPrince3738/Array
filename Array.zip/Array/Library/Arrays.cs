﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Arrays
    {
        public List<object> numsList = new List<object>();

        public List<object> Array1(int N)
        {
            int num = 1;
            while (num <= N)
            {
                numsList.Add(num);
                num += 2;
            }
            return numsList;
        }
        public List<object> Array3(int N, int A, int D)
        {
            for (int i = 0; i < N; i++)
                numsList.Add(A + D * i);
            return numsList;
        }
        public List<object> Array5(int N)
        {
            
            int num1 = 0;
            int num2 = 1;
            int num3 = 0;
            while (N > 0)
            {
                numsList.Add(num2);
                num3 = num2 + num1;
                num1 = num2;
                num2 = num3;
                N--;
            }
            return numsList;
        }
        public List<object> Array7(int[] nums)
        {
            for (int i = nums.Length - 1; i >= 0; i--)
                numsList.Add(nums[i]);
            return numsList;
        }
        public List<object> Array9(int[] nums)
        {
            for (int i = nums.Length - 1; i >= 0; i--)
                if (nums[i] % 2 == 0)
                    numsList.Add(nums[i]);
            numsList.Add("count: " + numsList.Count);
            return numsList;
        }
        public List<object> Array11(int[] nums, int K)
        {
            for (int i = K - 1; i <= (nums.Length - 1); i += K)
                numsList.Add(nums[i]);
            return numsList;
        }
        public List<object> Array13(int[] nums)
        {
            for (int i = nums.Length - 1; i >= 0; i -= 2)
                numsList.Add(nums[i]);
            return numsList;
        }
        public List<object> Array15(int[] nums)
        {
            for (int i = 0; i <= (nums.Length - 1); i += 2)
                numsList.Add(nums[i]);

            for (int i = nums.Length - (1 + nums.Length % 2); i >= 0; i -= 2)
                numsList.Add(nums[i]);

            return numsList;
        }
        public List<object> Array17(int[] nums)
        {
            for (int i = 0; i < nums.Length - nums.Length % 2; i += 2)
            {
                numsList.Add(nums[i]);
                numsList.Add(nums[i + 1]);
                numsList.Add(nums[nums.Length - (i + 1)]);
                numsList.Add(nums[nums.Length - (i + 2)]);
            }
            return numsList;
        }
        public List<object> Array19(int[] nums)
        {
            for (int i = 1; i < nums.Length - 1; i++)
                if (nums[i] > nums[0] && nums[i] < nums[nums.Length - 1])
                    numsList.Add(nums[i]);
            if (numsList.Count == 0)
                numsList.Add(0);
            return numsList;
        }
        public float Array21(int[] nums, int k, int l)
        {
            float sum = 0;
            for (int i = k - 1; i <= l - 1; i++)
                sum += nums[i];
            sum /= (l - k + 1);
            return sum;
        }
        public float Array23(int[] nums, int K, int L)
        {
            float sum = 0;
            for (int i = 0; i < K - 1; i++)
                sum += nums[i];
            for (int i = L - 1; i < nums.Length - 1; i++)
                sum += nums[i];
            sum /= nums.Length - (L - K + 1);
            return sum;
        }
        public float Array25(float[] nums)
        {
            float q = nums[1] / nums[0];
            for (int i = 0; i < nums.Length - 2; i++)
                if (nums[i + 1] / nums[i] != q)
                    q = 0;
            return q;
        }

        public void WriteDown(List<object> things)
        {
            foreach (object a in things)
                WriteDown(a);
        }
        public void WriteDown(object[] things)
        {
            foreach (object a in things)
                WriteDown(a);
        }
        public void WriteDown(object things)
        {
            Console.Write(things + " ");
        }
    }
}
